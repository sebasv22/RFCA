package weka.classifiers.trees.rfca;

import java.io.Serializable;

 /**
 <!-- globalinfo-start -->
 * The FileCA object represents a. ca or. caGold file, it allows 
 * to store the file name, the number of columns of the Covering Array 
 * or Tower Covering Array, this allows to locate the CA or TCA appropriate 
 * to the number of attributes, the selected CA o TCA will correspond 
 * to one whose number of attributes is less than or equal to the number
 * of columns of the Covering Array or Tower Covering Array .
 * <br/>
 * <br/>
 * For more information, see<br/>
 * <br/>
 * Leo Breiman (1996). Bagging predictors. Machine Learning. 24(2):123-140.
 * <p/>
 <!-- globalinfo-end -->
 *
 <!-- technical-bibtex-start -->
 * BibTeX:
 * <pre>
 * &#64;article{Breiman1996,
 *    author = {Leo Breiman},
 *    journal = {Machine Learning},
 *    number = {2},
 *    pages = {123-140},
 *    title = {Bagging predictors},
 *    volume = {24},
 *    year = {1996}
 * }
 * </pre>
 * <p/>
 <!-- technical-bibtex-end -->
 *
 <!-- options-start -->
 * Attributes are: <p/>
 * 
 * <pre> numAttributes
 *  number of attributes(number of columns) of a FileCA object, 
 *  the FileCA object represents a. ca or .caGold fie. </pre>
 * 
 * <pre> fileName
 * file name of a FileCA object, the FileCA object represents
 * a .ca or .caGold file. </pre> 
 * 
 <!-- options-end -->
 *
 * Options after -- are passed to the designated classifier.<p>
 *
 * @author Carlos Cobos
 * @author Sebastian Vivas (jusvivas@unicauca.edu.co)
 * @version $Revision: 1 $
 */
public class FileCA implements Comparable<FileCA>, Serializable {

    private int numAttributes;
    private String fileName;

    public FileCA() {
    }

    public FileCA(int numAttributes, String fileName) {
        this.numAttributes = numAttributes;
        this.fileName = fileName;
    }

    /**
     * Get the number of attributes of a FileCA object, the FileCA object
     * represents  a .ca or .caGold file.
     *
     * @return number of attributes of the FileCA object
     * @throws Exception if generation fails
     */
    public int getNumAttributes() {
        return numAttributes;
    }

    /**
     * Set the number of attributes of a FileCA object, the FileCA object
     * represents a .ca or .caGold file.
     *
     * @param numAttributes number of attributes to set
     * @throws Exception if generation fails
     */
    public void setNumAttributes(int numAttributes) {
        this.numAttributes = numAttributes;
    }

    /**
     * Get the file name of a FileCA object, the FileCA object represents
     * a .ca or .caGold file.
     *
     * @return file name of the FileCA object
     * @throws Exception if generation fails
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Set the file name of a FileCA object, the FileCA object represents a .ca
     * .caGold file.
     *
     * @param fileName file name of the FileCA object to set
     * @throws Exception if generation fails
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Compares the number of attributes of a FileCA object with another FileCA
     * object
     *
     * @param OtherArch FileCA object to compare
     * @return 0 - if the number of attributes of both FileCA objects to be
     * compared is the same 1 - if the number of attributes of the FileCA
     * OtherArch object is smaller -1 - if the number of attributes of the
     * FileCA OtherArch object is larger
     * @throws Exception if generation fails
     */
    @Override
    public int compareTo(FileCA OtherArch) {
        double numAttributesOtherArch = OtherArch.getNumAttributes();

        if (numAttributes == numAttributesOtherArch) {
            return 0;
        } else if (numAttributes > numAttributesOtherArch) {
            return 1;
        } else {
            return -1;
        }
    }

}
