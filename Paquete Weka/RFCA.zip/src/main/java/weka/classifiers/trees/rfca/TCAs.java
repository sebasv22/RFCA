package weka.classifiers.trees.rfca;

 
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;

 /**
 <!-- globalinfo-start -->
 * Class that represents a TCA object (files .caGold) ,in which, according to the strength selected in the binary matrix corresponding
 * to said strength, it also contains information about the number of rows and columns of the loaded TCA.
 * Each row of the TCA(binary matrix) represents a tree in the Random Forest. In which the attributes that will be used 
 * for the construction of that tree will be determined by positions of the row of the TCA whose 1. the positions 0 in
 * the row indicate that this attribute will not be used in the construction of the tree.
 * The number of rows of the towers covering array represented by the binary matrix indicates the number of trees to be constructed 
 * in the random forest.
 * <br/>
 * <br/>
 * TCA(Towers Covering Array)<br/>
 * <br/>
 * <br/>
 * For more information, see<br/>
 * <br/>
 * Leo Breiman (1996). Bagging predictors. Machine Learning. 24(2):123-140.
 * <p/>
 <!-- globalinfo-end -->
 *
 <!-- technical-bibtex-start -->
 * BibTeX:
 * <pre>
 * &#64;article{Breiman1996,
 *    author = {Leo Breiman},
 *    journal = {Machine Learning},
 *    number = {2},
 *    pages = {123-140},
 *    title = {Bagging predictors},
 *    volume = {24},
 *    year = {1996}
 * }
 * </pre>
 * <p/>
 <!-- technical-bibtex-end -->
 *
 <!-- options-start -->
 * Attributes are: <p/>
 * 
 * <pre> MatrixTCA
 *  TCA binary matrix from the selected strength</pre>
 * 
 * <pre> currentRow
 *  the position of the current row of the tower covering array 
 *  represented by the binary matrix.
 *  The construction of each tree in the Random Forest algorithm is 
 *  carried out progressively, so this attribute allows to know which
 *  row of the TCA to use for the construction of the tree </pre> 
 *
 * <pre> numRows
 *  number of rows of the selected TCA</pre>
 *
 * <pre> numColumn
 *  number of columns of the selected TCA.</pre>
 * 
 <!-- options-end -->
 *
 * Options after -- are passed to the designated classifier.<p>
 *
 * @author Carlos Cobos
 * @author Sebastian Vivas (jusvivas@unicauca.edu.co)
 * @version $Revision: 1 $
 */

public class TCAs implements Serializable {

    private int[][] MatrixTCA;
    private int currentRow;
    private int numRows;
    private int numColumn;
    private ArrayList<FileCA> ListFileTCA;
    private static TCAs instance;

    /*  Singleton Pattern Implementation */
    private TCAs() {
        this.MatrixTCA = new int[2][2];
        this.currentRow = -1;
        this.numRows = MatrixTCA.length;
        this.numColumn = MatrixTCA[0].length;
        this.ListFileTCA = getListFiles();
        /* Ascending order */
        Collections.sort(ListFileTCA);

        /* Descending order
         Collections.sort(ListFileTCA, Collections.reverseOrder());  */
    }

    /**
     * Obtain a TCA instance
     *
     * @return TCA instance
     * @throws Exception if generation fails
     */
    public static TCAs getInstance() {
        synchronized (TCAs.class) {
            if (instance == null) {
                instance = new TCAs();
            }
        }
        return instance;
    }

    /**
     * Reads the .caGold files(files corresponding to TCA) from the TCA folder
     * and stores FileCA objects in a list (ListFiles), in the objects FileCA
     * the TCA name and TCA attribute number are stored.
     *
     * @return list of FileCA objects, in the objects FileCA the TCA name and
     * TCA attribute number are stored.
     * @throws Exception if generation fails
     */
    public ArrayList<FileCA> getListFiles() {
        ArrayList<FileCA> ListFiles = new ArrayList<>();
        
        /*INICIO Para construir de acuerdo a las pruebas */
        
        // String dirCAs = "CAs\\TCA\\";
        // File folder = new File("./" + dirCAs);
        
        /*FIN Para construir de acuerdo a las pruebas */
        
        /* The default folder name for Weka bits and bobs */
        String dirCAs = "CAs\\TCA\\";
        String WEKAFILES_DIR_NAME = "wekafiles";
        String PACKAGE_NAME = "RFCA_RFTCA";
        String WEKA_HOME_DIR = System.getProperty("user.home") + File.separator + WEKAFILES_DIR_NAME
                + File.separator + "packages" + File.separator + PACKAGE_NAME;
        File folder = new File(WEKA_HOME_DIR + File.separator + dirCAs);
        
        File[] listOfFiles = folder.listFiles();
        FileCA fileCa;
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {
                String fileName = listOfFiles[i].getName();
                String numAttributes = fileName.substring(fileName.indexOf("k") + 1, fileName.indexOf("v"));
                int auxNumAttributes = Integer.parseInt(numAttributes);
                fileCa = new FileCA();
                fileCa.setFileName(fileName);
                fileCa.setNumAttributes(auxNumAttributes);
                ListFiles.add(fileCa);
            }
        }
        Collections.sort(ListFiles);
        return ListFiles;

    }

    /**
     * Gets the TCA file name according to the number of dataset attributes
     *
     * @param numAttributes number of Dataset attributes
     * @return TCA file name according to the number of dataset attributes
     * @throws Exception if generation fails
     */
    public String getNameTCA(int numAttributes) {
        String nameCA = "";

        for (int i = 0; i < ListFileTCA.size(); i++) {
            if (numAttributes <= ListFileTCA.get(i).getNumAttributes()) {
                nameCA = ListFileTCA.get(i).getFileName();
                break;
            }
        }
        return nameCA;
    }

    /**
     * Sets the TCA file name according to the number of dataset attributes 
     * and the strength value selected
     *
     * @param dirFile direction corresponding to the TCA files folder
     * @param strengthVal selected strength value
     * @param numAtributes number of Dataset attributes
     * @throws Exception if generation fails
     */
    public void setTCAmatrix(String dirFile, String strengthVal, int numAtributes) {
        FileAux arch = new FileAux();
        int[][] Data = null;

        try {

            Data = arch.loadDataTCAsnumAtri(dirFile, strengthVal, numAtributes);
            this.MatrixTCA = Data;
            this.numRows = MatrixTCA.length;
            this.numColumn = MatrixTCA[0].length;
        } catch (IOException ex) {
            Logger.getLogger(TCAs.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * From the current row of the TCA you get the positions in which an
     * attribute is selected, that is, where the value of 1
     *
     * @return List of positions of the selected attributes
     * @throws Exception if generation fails
     */
    public ArrayList<Integer> SelectColumns() {
        ArrayList<Integer> columnsSelected = new ArrayList<>();
        int rowCurrent = getCurrentRow();
        for (int j = 0; j < numColumn; j++) {
            if (MatrixTCA[rowCurrent][j] != 0) {
                columnsSelected.add(j);
            }

        }
        return columnsSelected;
    }

    /**
     * Get the position of the current row
     *
     * @return current row position
     * @throws Exception if generation fails
     */
    public int getCurrentRow() {
        this.currentRow = this.currentRow + 1;
        double mod = this.currentRow % this.numRows;
        Double modulo = mod;
        int RowAct = modulo.intValue();

        return RowAct;
    }

    /**
     * Resets the auxiliary variable indicating the row to be used in the
     * construction of a tree
     *
     * @param currentRow row position to set
     * @throws Exception if generation fails
     */
    public void setCurrentRow(int currentRow) {
        this.currentRow = currentRow;
    }

    /**
     * Get the TCA matrix from the selected strength
     *
     * @return TCA matrix
     * @throws Exception if generation fails
     */
    public int[][] getMatrixTCA() {
        return MatrixTCA;
    }

    /**
     * Set the TCA matrix
     *
     * @param MatrixTCA matrix to set
     * @throws Exception if generation fails
     */
    public void setMatrixTCA(int[][] MatrixTCA) {
        this.MatrixTCA = MatrixTCA;
    }

    /**
     * Gets the number of rows of the selected TCA
     *
     * @return number of rows of the selected TCA
     * @throws Exception if generation fails
     */
    public int getNumRows() {
        return numRows;
    }

    /**
     * Set the number of rows of the TCA
     *
     * @param numRows number of rows to set
     * @throws Exception if generation fails
     */
    public void setNumRows(int numRows) {
        this.numRows = numRows;
    }

    /**
     * Get the number of columns of the TCA
     *
     * @return number of columns of the TCA
     * @throws Exception if generation fails
     */
    public int getNumColumn() {
        return numColumn;
    }

    /**
     * Set the number of columns of the TCA
     *
     * @param numColumn number of columns to set
     * @throws Exception if generation fails
     */
    public void setNumColumn(int numColumn) {
        this.numColumn = numColumn;
    }

    public ArrayList<FileCA> getListFileTCA() {
        return ListFileTCA;
    }

    public void setListFileTCA(ArrayList<FileCA> ListFileTCA) {
        this.ListFileTCA = ListFileTCA;
    }

}
